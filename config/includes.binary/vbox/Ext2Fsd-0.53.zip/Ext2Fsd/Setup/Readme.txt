
--> Setup.bat

    To install ext2fsd to your system. 


--> Uninstall.bat

    To remove ext2fsd from your system.


--> w2k

    free build for windows 2000.


--> wxp

    free build for windows xp.

--> wnet

    free build for windows xp and 2003

--> wlh

    free build for windows vista, win7 and 2008




