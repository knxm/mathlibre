
--> Setup.bat

    To install ext2fsd to your system. 

--> Uninstall.bat

    To remove ext2fsd from your system.

--> w2k/i386

    free build for windows 2000 x86.

--> wxp/i386

    free build for windows xp/vista/win7win8/2003/2008 x86.

--> wxp/amd64

    free build for windows xp/vista/win7win8/2003/2008 amd64.



